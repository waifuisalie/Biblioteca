package com.biblioteca;

public interface CalculaMulta {
    // método para calcular a multa com base em um objeto de empréstimo
    double calcularMulta(Emprestimo emprestimo);
}
